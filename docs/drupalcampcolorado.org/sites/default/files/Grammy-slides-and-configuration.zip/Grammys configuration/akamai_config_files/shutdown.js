function callserver() {
var xmlHttp = false;
  try {
  xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
  } 
  catch (e) {
    try {
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    catch (e2) {
    xmlHttp = false;
    }
  }
  if (!xmlHttp && typeof XMLHttpRequest != 'undefined') {
  xmlHttp = new XMLHttpRequest();
  }
var url = "/portal/portal_info.jsp?alertNotify=true";
xmlHttp.open("GET", url, true);
xmlHttp.send(null);
}

function sdcountdown() {
var newcountdown = new Date();
var showsecond = sdcountdowncome.getSeconds()-newcountdown.getSeconds();
var showminute = sdcountdowncome.getMinutes()-newcountdown.getMinutes();
  if (showsecond < 0 ) {
  showsecond = 60 + showsecond;
  showminute = showminute - 1;
  }

  if (showminute < 0) {
  	return;
  }

  if (showminute < 5) {
  document.getElementById("shutdownmsg").className="shutdownboxlastfive";
  document.getElementById("shutdowncounter").innerHTML= "EdgeControl will shut down in: <span class='shutdownminute'>" + showminute + "m " + showsecond + "s</span>";
  } 
  else {
    if (showsecond == 0) {
    document.getElementById("shutdowncounter").innerHTML="EdgeControl will shut down in: <span class='shutdownminute'>" +  showminute +"</span> minutes";
    } 
    else {
    document.getElementById("shutdowncounter").innerHTML= "EdgeControl will shut down in: <span class='shutdownminute'>" +(showminute+1) + "</span> minutes ";
    }
  }
  setTimeout("sdcountdown()",1000);
}
  		
function initcountdown() {
  if (secLeft <= 0) {
  return;
  }
  else if (secLeft > alertT) {
  var di = (secLeft - alertT) * 1000;
  secLeft = alertT;
  setTimeout("initalert()", di);
  }
  else if (secLeft <= alertT) {
  initalert();
  }
}
<?php
$db_url = 'mysql://user:pass@10.20.222.10/grammys_drupal';
$db_slave_url = 'mysql://user:pass@localhost/grammys_drupal';
$db_prefix = '';

/**
 * Access control for update.php script
 */
$update_free_access = FALSE;

/**
 * PHP settings:
 *
 * To see what PHP settings are possible, including whether they can
 * be set at runtime (ie., when ini_set() occurs), read the PHP
 * documentation at http://www.php.net/manual/en/ini.php#ini.list
 * and take a look at the .htaccess file to see which non-runtime
 * settings are used there. Settings defined here should not be
 * duplicated there so as to avoid conflict issues.
 */
ini_set('arg_separator.output',     '&amp;');
ini_set('magic_quotes_runtime',     0);
ini_set('magic_quotes_sybase',      0);
ini_set('session.cache_expire',     200000);
ini_set('session.cache_limiter',    'none');
ini_set('session.cookie_lifetime',  1800); // Longer cookies are provided by remember_me module.
ini_set('session.gc_maxlifetime',   200000);
ini_set('session.save_handler',     'user');
ini_set('session.use_cookies',      1);
ini_set('session.use_only_cookies', 1);
ini_set('session.use_trans_sid',    0);
ini_set('url_rewriter.tags',        '');

// If the user has submitted a form, give them uncached pages as if they were an
// authenticated user.
if (isset($_COOKIE['NO_CACHE']) && $_COOKIE['NO_CACHE'] == 'Y') {
  drupal_page_is_cacheable(FALSE);
}

// 10.20.222.10 is the Database server, also serving as the Memcached server.
$conf['cache_inc'] = 'sites/all/modules/contrib/memcache/memcache.inc';
$conf['session_inc'] = 'sites/all/modules/contrib/memcache/memcache-session.inc';
$conf['memcache_servers']['10.20.222.10:11211'] = 'default';
$conf['memcache_servers']['10.20.222.10:11212'] = 'block';
$conf['memcache_servers']['10.20.222.10:11213'] = 'content';
$conf['memcache_servers']['10.20.222.10:11214'] = 'filter';
$conf['memcache_servers']['10.20.222.10:11215'] = 'form';
$conf['memcache_servers']['10.20.222.10:11216'] = 'menu';
$conf['memcache_servers']['10.20.222.10:11217'] = 'mollom';
$conf['memcache_servers']['10.20.222.10:11218'] = 'page';
$conf['memcache_servers']['10.20.222.10:11219'] = 'views';
$conf['memcache_servers']['10.20.222.10:11220'] = 'views_data';
$conf['memcache_servers']['10.20.222.10:11221'] = 'sessions';
$conf['memcache_servers']['10.20.222.10:11222'] = 'users';
$conf['memcache_servers']['10.20.222.10:11223'] = 'path_source';
$conf['memcache_servers']['10.20.222.10:11224'] = 'path_dest';

$conf['memcache_bins'] = array(
  'sessions' => 'sessions',
  'cache' => 'default',
  'cache_block' => 'block',
  'cache_content' => 'content',
  'cache_filter' => 'filter',
  'cache_form' => 'form',
  'cache_menu' => 'menu',
  'cache_mollom' => 'mollom',
  'cache_page' => 'page',
  'cache_views' => 'views',
  'cache_views_data' => 'views_data',
  'cache_users' => 'users',
  'cache_pathsrc' => 'path_source',
  'cache_pathdst' => 'path_dest',
);

# Required for getting correct user IPs. See ip_address().
$conf['reverse_proxy'] = TRUE;
$conf['reverse_proxy_addresses'] = array(
  '10.10.222.10',
  '10.10.222.20',
  '10.10.222.30',
  '10.10.222.40',
  '10.10.222.50',
  '10.10.222.60',
  '10.10.222.70',
  '10.10.222.80',
);
